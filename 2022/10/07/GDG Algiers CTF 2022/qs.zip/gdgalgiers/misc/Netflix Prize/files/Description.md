Netflix data has been leaked 😟
I think it's the perfect time to sneak and get some insights about what a close friend could be watching 👀, unfortunately data has been anonymized but I heared that some of you could help me finding his record, for that let me help you with what I know:


*   I've seen him talking about the `Ghost Writer, The (2010)	` and he was saying that he didn't like it that much, this dates back to 2012
*   He was also talking about `This fool (2002)` and saying that he did like it, not a 10 tho. this dates back to `2006-10-12`.
*   Finally, he did mention the name of a famous film `Harry Potter and the Deathly Hallows: Part 2 (2011)`, saying he did really like it, this dates back to `2012-04-24`

**NOTES**:
* that timestamp are days from `1998-10-01`(YY-MM-DD)
* there might be some familiar records, try the top ones!
* our information are not 100% accurate

**LINK** : https://drive.google.com/drive/folders/14Av9cPmRGX3oa3H_1qKjBNmhDT5OQCsz?usp=sharing  