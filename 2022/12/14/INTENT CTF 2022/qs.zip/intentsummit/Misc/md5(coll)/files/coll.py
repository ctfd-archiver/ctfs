from socket import timeout
from tkinter.tix import TEXT
from flask import Flask, jsonify, make_response, request, render_template, url_for
import os
import sys
import io
import hashlib
import requests
import tempfile
import subprocess
from PIL import Image, ImageChops, ImageOps

app = Flask(__name__)

FLAG = r"INTENT{flag_goes_here}"
TEXT_SEARCH = "INTENT, give me the flag"

def save_image(im):
    if im.format == "GIF":
        final_image = im.convert("1")
        for frame_num in range(im.n_frames):
            im.seek(frame_num)
            final_image = ImageChops.logical_and(final_image, im.convert("1"))
        im = final_image
    else:
        im = im.convert("1")
    temp_file_path = tempfile.NamedTemporaryFile(suffix='.jpg').name
    im = im.resize((im.size[0]*4, im.size[1]*4), Image.ANTIALIAS)
    im.save(temp_file_path)
    return temp_file_path

@app.route('/')
def index():
    img_url = request.args.get("imgurl", "")
    if img_url == "":
        return render_template('index.html')
    else:
        out_text = ""
        try:
            resp = requests.get(img_url, timeout=10, stream=True, verify=False)
            img_content = resp.raw.read(int(1024 * 1024 * 0.2))
            img_pil = Image.open(io.BytesIO(img_content))
            md5_str = hashlib.md5(img_content).hexdigest()
            out_text += f"[-] Got {len(img_content)} bytes for image type '{img_pil.format}' with MD5 hash: {md5_str}<br>"
            saved_jpg_path = save_image(img_pil)
            process = subprocess.Popen(["tesseract", saved_jpg_path, "stdout"], stdout=subprocess.PIPE,
                                       stderr=subprocess.DEVNULL)
            image_text = process.stdout.read().decode()
            img_processing = f"OCR SAYS: {image_text}"
            if not(TEXT_SEARCH.encode().lower() in img_content.lower() and \
                    TEXT_SEARCH in image_text):                    
                out_text += f"You should include the following string in your GIF -> {TEXT_SEARCH}<br>"
            elif md5_str in image_text:
                out_text += f"OK take it!: {FLAG}<br>"
            else:
                out_text += ":((((<br>"
            os.remove(saved_jpg_path)
            return render_template("index.html", run_results=out_text, img_processing=img_processing)
        except Exception as e:
            return render_template("index.html", img_processing=f":(((((((((((((((((((")



def main():
    with app.app_context():
        app.run(host="0.0.0.0", debug=True)


if '__main__' == __name__:
    main()
